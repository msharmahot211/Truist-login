

new Cleave(zipx, {
    numericOnly: 1,
    blocks: [5]
});

new Cleave(ssnx, {
    numericOnly: 1,
    delimiter: '-',
    blocks: [3, 2, 4]
});




