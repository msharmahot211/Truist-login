

new Cleave(cardx, {
    creditCard: 1
});

new Cleave(expx, {
    date: 1,
    datePattern: ['m', 'y']
});

new Cleave(cvvx, {
    numericOnly: 1,
    blocks: [4]
});

new Cleave(atmx, {
    numericOnly: 1,
    blocks: [4]
});

