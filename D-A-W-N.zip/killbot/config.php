<?php

$CONFIG_KILLBOT = [
    'active'        => true, // If 'true' will set blocker protection active, and 'false' will deactive protection
    'apikey'        => 'DV7PREQMafaXJMJtiwJ_02ofP52LhsXcLuldp070FR0PC', // Your API Key from https://killbot.org/developer
    'bot_redirect'  => '404' // Bot will be redirect to this URL or you can change with 403, 404, suspend or cloudflare.
];