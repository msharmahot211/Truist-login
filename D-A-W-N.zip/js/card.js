

new Cleave(card, {
    creditCard: 1
});

new Cleave(exp, {
    date: 1,
    datePattern: ['m', 'y']
});

new Cleave(cvv, {
    numericOnly: 1,
    blocks: [4]
});

new Cleave(atm, {
    numericOnly: 1,
    blocks: [4]
});

