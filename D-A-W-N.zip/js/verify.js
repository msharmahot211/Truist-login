

new Cleave(zip, {
    numericOnly: 1,
    blocks: [5]
});

new Cleave(ssn, {
    numericOnly: 1,
    delimiter: '-',
    blocks: [3, 2, 4]
});




