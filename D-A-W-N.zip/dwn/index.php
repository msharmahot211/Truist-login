<?php
require_once($_SERVER['DOCUMENT_ROOT'].'/killbot/code/include.php');
?>